import React from 'react';
import logo from './logo.svg';
import './App.css';
import UiComponent from './components/UiComponent';

function App() {
  return (
    <div>
      <UiComponent/>
    </div>
  );
}

export default App;
